package com.cgg.data2.service;

public interface CompanyService {


}
