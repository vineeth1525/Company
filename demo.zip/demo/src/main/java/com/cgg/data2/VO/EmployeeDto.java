package com.cgg.data2.VO;

import com.cgg.data2.VO.EmployeeDto;

import lombok.Data;

@Data
public class EmployeeDto {
private String employeeName;
private String dept;
private long salary;
private int id;


}
